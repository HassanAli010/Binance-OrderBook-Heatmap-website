import DashboardManager from './DashboardManager.js';
import UI from './UI.js';

const dm = new DashboardManager();
const ui = new UI(dm);
